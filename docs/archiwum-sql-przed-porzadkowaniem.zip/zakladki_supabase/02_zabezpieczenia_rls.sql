-- Secure RLS policies (production-safe default).
-- This blocks all anon/public access and relies on the server (service role).

-- Enable RLS on core tables
alter table if exists public.halls enable row level security;
alter table if exists public.locations enable row level security;
alter table if exists public.materials enable row level security;
alter table if exists public.daily_entries enable row level security;
alter table if exists public.daily_location_status enable row level security;
alter table if exists public.audit_logs enable row level security;
alter table if exists public.app_users enable row level security;

-- Drop public read/write policies
drop policy if exists "halls_read" on public.halls;
drop policy if exists "locations_read" on public.locations;
drop policy if exists "materials_read" on public.materials;
drop policy if exists "daily_entries_read" on public.daily_entries;
drop policy if exists "daily_locations_read" on public.daily_location_status;
drop policy if exists "audit_read" on public.audit_logs;

drop policy if exists "halls_write" on public.halls;
drop policy if exists "locations_write" on public.locations;
drop policy if exists "materials_write" on public.materials;
drop policy if exists "daily_entries_write" on public.daily_entries;
drop policy if exists "daily_locations_write" on public.daily_location_status;
drop policy if exists "audit_write" on public.audit_logs;

-- Optional: allow authenticated (Supabase Auth) read-only access
-- Uncomment if you later use Supabase Auth on the client.
-- create policy "halls_read_auth" on public.halls
--   for select to authenticated using (true);
-- create policy "locations_read_auth" on public.locations
--   for select to authenticated using (true);
-- create policy "materials_read_auth" on public.materials
--   for select to authenticated using (true);
-- create policy "daily_entries_read_auth" on public.daily_entries
--   for select to authenticated using (true);
-- create policy "daily_locations_read_auth" on public.daily_location_status
--   for select to authenticated using (true);
-- create policy "audit_read_auth" on public.audit_logs
--   for select to authenticated using (true);
